﻿using UnityEngine;
using System.Collections;

public class PlayGame : MonoBehaviour {

	public void LoadLevel()
	{
		Application.LoadLevel("SceneGame");
	}
}
